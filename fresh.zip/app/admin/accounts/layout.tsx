export default function AccountsLayout({ children }: { children: React.ReactNode }) {
  return <div className="container-pg py-8">{children}</div>
}


