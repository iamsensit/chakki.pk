export { auth } from '@/app/lib/auth.config'
